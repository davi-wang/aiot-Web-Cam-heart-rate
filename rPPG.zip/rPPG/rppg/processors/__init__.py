from .processor import Processor, FilteredProcessor
from .color_mean import ColorMeanProcessor
from .chrom import ChromProcessor
from .pos import PosProcessor
from .li_cvpr import LiCvprProcessor
